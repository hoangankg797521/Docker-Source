# Changelog

## 2.15.1-ddns.2 — 2026-10-16

- Khi mở Access List đã có DDNS rule, tự chuyển Rule Type sang DDNS sau khi API tải xong; rule vẫn được lấy từ API, không phụ thuộc lựa chọn mặc định IP.
- Cấu hình resolver DDNS chính/dự phòng `8.8.8.8,1.1.1.1`; không thay DNS của host hoặc Docker.
- Đã triển khai trên production `10.0.1.248`, backup trước cutover và giữ nguyên database, proxy host, certificate cùng file Let’s Encrypt.


## 2.15.1-ddns.1 — 2026-10-16

- Thêm bảng rule, policy fail-closed và history bằng migration riêng.
- Thêm resolver A/AAAA, timeout/retry/backoff, stale TTL và scheduler bền qua restart.
- Thêm DDNS rule editor, trạng thái, refresh thủ công và lịch sử trong Access List của React frontend.
- Tích hợp include ACL, giữ nguyên thứ tự rule thủ công và authentication.
- Snapshot/restore cấu hình liên quan khi nginx test/reload thất bại; đồng bộ với thao tác Nginx khác.
- Pin base image đúng digest NPM 2.15.1 production; staging tách biệt, giới hạn tài nguyên và rotation log.
- Thêm startup hook xóa grant DDNS lưu cũ trước khi Nginx chạy; scheduler chỉ khôi phục IP còn hạn.
- Preflight toàn bộ DDNS payload trước khi tạo/sửa Access List, tránh ACL rỗng khi input lỗi.
- Thêm unit, migration, integration tests, script backup và tài liệu rollback/nâng cấp.
