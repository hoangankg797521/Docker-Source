# Production fix — NPM 10.0.1.248 — 2026-10-16

- Root cause: the Access List modal initialized Rule Type to IP on every open. The DDNS component fetched existing rows but did not tell the parent selector to reveal them, so refresh/remount hid the existing DDNS rules.
- Fixed in `upstream/frontend/src/modals/AccessListModal.tsx` and `upstream/frontend/src/components/Form/DDNSFields.tsx`: after the initial successful API fetch, an existing DDNS row selects DDNS; later polling does not override the user’s selection.
- DNS had intermittent `ETIMEOUT`/`ESERVFAIL`. Production now uses `DDNS_RESOLVERS=8.8.8.8,1.1.1.1`. Both resolvers independently resolved the configured hostname during direct checks. After one transient `ESERVFAIL`, the normal Refresh Now API action succeeded; rule 1 is `Active`, failures `0`, and one dynamic grant is present in its Nginx include.
- Built and deployed `local/npm:2.15.1-ddns.2` (image ID `sha256:ead4779ffe001ffaebe8ee55aca6c46e39d7771547664760b3d77375c8a9fa08`). Production container is running; `docker compose config --quiet`, API login, SQLite `integrity_check`, and `nginx -t` passed. Temporary staging containers were stopped after tests.
- Backup verified before change: `/var/backups/npm-ddns-pre-ui-fix/20261016T143658Z`. All 20 DB tables matched the snapshot, except expected DDNS status/time fields updated by resolver; data and Let’s Encrypt manifest hashes matched. Proxy Host and certificate rows stayed unchanged: 17 active proxy hosts, 18 certificates; all enabled host HTTP/TLS checks passed. Existing five manual IP/CIDR rules remain.
- Frontend TypeScript compile and Vite build passed; DDNS core and lock tests passed 10/10. Read-only headless Chrome verification against the production Access List passed: opening the existing ACL selected DDNS automatically and displayed its Hostname field; modal was canceled without saving. Production-served frontend bundle matched the local `.2` build byte-for-byte.
- Rollback snapshot includes both original Compose files, image inspect, database, data and certificate volumes. Follow `ROLLBACK.md`; do not only change the image tag because the DDNS migration has already run.

# Hồ sơ kiểm chứng và duyệt production — 16/10/2026

**Trạng thái: đã triển khai production trên `10.0.1.248` ngày 16/10/2026.** Historical snapshot at this point records image `.1`; current production fix is documented at the top of this file.

## Hiện trạng đã khảo sát

- Debian 13 / amd64, Docker Engine `26.1.5+dfsg1`, Compose `2.26.1-4`.
- NPM `2.15.1`, build commit `76f09db6`.
- Image production khai báo `jc21/nginx-proxy-manager:latest`, thực tế pin được digest `sha256:52b2c59994f3d36acfcf70a1626f29734df0ed8c71bacc0269f78b6f939858bb`.
- Container `nginx-proxy-manager`, Compose project `npm`, service cùng tên, file `/opt/npm/docker-compose.yml`.
- Port production 80/81/443, network `npm_default`, restart `unless-stopped`; không đổi các thông số này.
- Bind mounts `/opt/npm/data:/data` và `/opt/npm/letsencrypt:/etc/letsencrypt`; SQLite `/data/database.sqlite`.
- 13 Proxy Host đang hoạt động, 15 certificate chưa soft-delete, 1 Access List với 9 rule IP/CIDR. Tổng các row gồm soft-delete khác các con số active này.
- Không có Docker HEALTHCHECK được cấu hình; đánh giá bằng process running, API HTTP và `nginx -t`, không gọi nhầm là Docker healthcheck passed.
- 4 file backend then chốt khớp SHA256 giữa tag chính thức và container. NPM gốc 2.15.1 chỉ render client IP/CIDR, chưa có resolver DDNS ACL.
- PR #4386 được đọc để tham khảo; không cherry-pick/merge. Trạng thái GitHub API và danh sách 11 file nằm trong `pr4386-status.json`. PR dùng CommonJS/EJS, khác backend ESM và React/TypeScript hiện tại.

## Backup và rollback đã thực hiện

- Backup ban đầu: `/var/backups/npm-ddns/20261016T071757Z`.
- Backup hoàn chỉnh gần nhất trước migration, kèm SQLite snapshot, data/SSL, log và runtime config: **`/var/backups/npm-ddns/20261016T084518Z`**.
- Đã dùng SQLite Backup API, `integrity_check`, đối chiếu `data_version`, manifest cấu hình/SSL trước-sau, SHA256, giải nén và đọc lại.
- Restore offline từ backup đã qua `nginx -t` bằng image gốc. Bản sao restore: `/opt/npm-ddns-staging/restore-validation/20261016T084527Z`.
- Đã diễn tập custom image → dừng container thử → giữ bản custom state → phục hồi snapshot trước migration → chạy image gốc, không network, không publish port. Các row ở 7 bảng cũ được đối chiếu đầy đủ.
- Diễn tập trên image chốt `sha256:514862beb628a72ef3c309da9113cad2d39256cc1216dbbaea493aa5c9ca4d04`: custom start 67.00 giây, rollback start 67.42 giây, không network/cổng publish; kết quả PASS tại `/opt/npm-ddns-staging/rollback-rehearsal/20261016T105535Z`.
- Script migration trên bản sao database đã chạy up/down hai lần; schema và toàn bộ row của bảng cũ giữ nguyên, integrity đạt.
- Backup chứa dữ liệu nhạy cảm và ở lại server, quyền root-only; không tải dump/private key vào bộ source và không push Git.

## Kết quả kiểm thử

Bằng chứng JSON được giữ kèm source; kết quả lượt cuối được cập nhật sau khi hoàn tất.

| Nhóm | Phạm vi |
|---|---|
| Unit | 10 case: hostname/injection, settings bounds, A/AAAA normalization, private/reserved IP policy, stale TTL, TTL=0, thay IP và khóa reentrant |
| Backend integration | 19 case: DNS, manual ACL, đổi IP, NXDOMAIN/timeout, fail-closed, API authorization/ownership, auth, rollback file khi Nginx lỗi, restart, scheduler, history. Preflight riêng trên image cuối: 3 payload create không hợp lệ và một update ID ngoài list trả 400, không tạo/sửa ACL. |
| Bổ sung | 6 case: đủ 9 rule production trên staging, IPv6 opt-in/default off, Auto Refresh off + TTL, thứ tự deny, legacy auth-only |
| Browser | 8 case trên Chrome headless riêng: login, DDNS-only create/edit/delete, refresh/history, trạng thái, mobile 390 px, không lỗi JS/console |
| Kết nối khi reload | Satisfy Any và phản hồi HTTP stream đang chạy trong lúc DDNS đổi IP/reload |
| Batch DNS | Nhiều hostname timeout không giữ HTTP lock cho toàn bộ DNS batch; TTL của list khác vẫn được thực thi |
| Migration | Trên bản sao backup, up/down hai lần; các bảng và row cũ giữ nguyên, `integrity_check=ok` |
| DNS thật | API → resolver `8.8.8.8` → Nginx trên staging: `one.one.one.one` trả `1.0.0.1` và `1.1.1.1`, client được phép HTTP 200, IP khác HTTP 403 |
| Khởi động fail-closed | Mô phỏng stale cache hết TTL khi container staging tắt; response HTTP đầu tiên sau start là 403 trước khi backend API sẵn sàng, rule IP thủ công vẫn HTTP 200 |
| Build/lint | TypeScript + Vite build đạt; lint phần DDNS không có error. Có cảnh báo kích thước bundle >500 kB, không thay dependency để xử lý cảnh báo này |

## Baseline lịch sử trước đó — máy 172.16.0.222

Trước khi inventory được chuyển sang host `10.0.1.248`, API của host `172.16.0.222` đăng nhập thành công. Đã gửi GET chỉ đọc đến 13 host theo cấu hình và xác minh CA/hostname TLS trực tiếp cho cả 12 host có cấu hình SSL. Host còn lại không dùng SSL.

**Proxy Host ID 22 trả HTTP 502 ngay ở baseline, trước mọi cutover.** Các host khác trả 301 (ép HTTPS) hoặc 200 theo cấu hình. `nginx_online=true` chỉ xác nhận cấu hình Nginx, không chứng minh upstream khỏe. Không sửa upstream ID 22 trong tính năng DDNS này.

Tại baseline cũ trên `172.16.0.222`, đã đối chiếu container ID, image ID, StartedAt và các bảng Access List/clients/auth, Proxy Host, certificate, redirect, stream; khi đó production giữ nguyên và chưa có bảng/migration DDNS. Cutover cũ trên host này được ghi riêng trong lịch sử task; deployment hiện cần tham chiếu là mục `10.0.1.248` bên dưới.

Nguồn IP được Nginx đánh giá là `$remote_addr`, sau real-IP processing hiện có: tin `X-Real-IP` từ các dải private và CDN cấu hình sẵn, `real_ip_recursive on`. Test staging xác nhận `X-Forwarded-For` giả mạo không đổi kết quả ACL; `X-Real-IP` từ peer private được tin đúng như cấu hình NPM gốc. **Không nới trusted proxy hoặc tự tin toàn bộ XFF.**

DNS stub Docker `127.0.0.11` và nameserver nội bộ `172.16.0.222` timeout khi truy vấn public DNS từ container; `8.8.8.8` trong `/etc/resolv.conf` của host đã được xác minh kết nối được. At that time staging and override used `DDNS_RESOLVERS=8.8.8.8` for DDNS; không thay DNS toàn host, Docker hay AdGuard.

Chưa kiểm chứng bằng client WAN/Cloudflare/load balancer thực tế của người quản trị, chưa có hostname DDNS thực tế của người dùng được gán production. IPv6 mới được kiểm tra DNS/render và nguồn IP giả lập trên staging; không tuyên bố đã kiểm tra đường truyền IPv6 Internet. IPv6 cho DDNS vẫn tắt mặc định.

Trình duyệt tích hợp mở được trang NPM; thông báo API unhealthy xuất hiện trong lúc chủ động restart/recreate staging là trạng thái backend khởi động, không phải lỗi render/certificate. Kiểm thử UI đăng nhập và thao tác được thực hiện bằng Chrome headless với profile thử riêng, credential qua bộ nhớ/stdin; không mở hoặc điều khiển profile Chrome cá nhân. Không bypass TLS/certificate warning.

## Production deployment trên 10.0.1.248

- Backup verified trước cutover: `/var/backups/npm-ddns/20261016T115310Z`; 17 bảng SQLite so sánh chính xác với snapshot. Compose gốc được giữ trong `docker-compose.yml` của backup.
- Image được build từ source bundle có SHA256 `85a2f3c2c81100a96e44b18e3922c6eee0af9f42f54dd76ca71a1b12b73b3205`, base digest khớp NPM chính thức đã chạy. Image ID trên host mới: `sha256:19f12bd470717acc663463014142edec0e893b749dbecbf1fa0d4dcb86008bef`.
- Compose override `/opt/npm/docker-compose.ddns.yml` bật `DDNS_RESOLVERS=8.8.8.8` và JSON log rotation 10 MB × 3. Service `npm` được recreate; giữ nguyên `TZ`, port 80/81/443, bind mount `/opt/npm/data` và `/opt/npm/letsencrypt`, network `npm_default`, restart `unless-stopped`.
- Migration `20261016070000_ddns_access.js` đã chạy; ba bảng DDNS tồn tại và hiện rỗng. API Access List trả về ACL 1 cùng 5 rule IP/CIDR cũ; chưa tạo rule DDNS vì chưa có hostname người dùng để cấu hình.
- Bảo toàn dữ liệu: cả 20 hàng `proxy_host` và 18 hàng `certificate` khớp từng hàng với backup; SHA256 của 206 file trong volume Let’s Encrypt cũng khớp hoàn toàn. SQLite integrity trả `ok`.
- Sau cutover: container running, API admin HTTP 200, `nginx -t` thành công, resolver trả về `1.0.0.1` và `1.1.1.1` cho `one.one.one.one`; 14/14 Proxy Host active trả HTTP 301 và 14/14 certificate đang dùng được xác minh TLS.
- Chưa kiểm chứng truy cập từ WAN/CDN thực tế hoặc IPv6 Internet. Tính năng DDNS đã bật nhưng chưa có hostname DDNS production; cần thêm hostname trong Access List để bắt đầu cấp quyền động.
- Rollback: dùng Compose gốc trong backup cùng image/config gốc; nếu migration đã chạy, khôi phục theo `ROLLBACK.md` và snapshot trước migration, không chỉ đổi image tag. Không dùng `docker compose down -v`.


## NPM backup server 192.21.30.249

- User identified this as the old NPM instance used for backups. At connection time its container was already stopped (exit 0) for five days, with `restart: "no"`; it remains stopped.
- Backup verified: `/var/backups/npm-ddns/20261016T120920Z`. All 17 DB tables and all 248 files in the data/Let’s Encrypt volume matched the snapshot before changing Compose. Proxy Host rows (20) and certificate rows (18) are preserved exactly; SQLite integrity is `ok`.
- Historical backup server setup built `local/npm:2.15.1-ddns.1` on the host from the verified source archive and pinned official base digest. Compose `/opt/nginx-proxy-manager/docker-compose.yml` selects that image, sets `DDNS_RESOLVERS=8.8.8.8`, and enables JSON log rotation (10 MB × 3). Ports, mounts, `TZ`, and `restart: "no"` remain unchanged; `docker compose config --quiet` passed.
- The stopped container still references the original image because it was not recreated or started. To activate DDNS later, intentionally run `docker compose up -d` in `/opt/nginx-proxy-manager`; that first start applies the custom image and runs the migration. The verified backup is the rollback source.
