# NPM 2.15.1 — DDNS Access Lists

Bản mở rộng dành cho đúng NPM **2.15.1**, giữ base image theo digest production trong `PROVENANCE.json`. Source gốc chính thức nằm trong `upstream/`; không merge PR #4386. Repository riêng dùng branch `codex/ddns-access-list`; chưa push.

## Cách hoạt động

- Access List → Rules → Rule Type → **DDNS / Domain** → **Add DDNS Rule**.
- Nhập hostname trực tiếp, ví dụ `home.example.com`; không cần `ddns:`.
- Chọn Enabled, Auto Refresh, IPv6 nếu cần; mặc định IPv6 tắt.
- Refresh interval mặc định **60 giây**, phạm vi 60–86400; Stale IP TTL mặc định **300 giây**, phạm vi 0–604800.
- **Save** Access List để áp dụng thêm/sửa/xóa. Các rule mới được lưu ở trạng thái **Updating**, chưa cấp quyền, rồi scheduler phân giải DNS; việc lưu nhiều hostname không chờ toàn bộ DNS trong request. **Refresh DNS Now** kiểm tra rule đã lưu; **View History** xem lịch sử.
- UI cập nhật trạng thái mỗi 10 giây, giữ nguyên các giá trị đang sửa chưa lưu.
- Cả IP và CIDR thủ công vẫn dùng cách nhập cũ. Thứ tự Allow/Deny thủ công giữ nguyên; quyền Allow từ DDNS nằm sau các rule thủ công, trước `deny all` mặc định. Rule `deny all` thủ công sẽ chặn cả DDNS ở phía sau.
- Authentication, Pass Auth và Satisfy Any giữ nguyên ngữ nghĩa NPM. Với Satisfy Any, credentials hợp lệ vẫn có thể cho phép truy cập khi điều kiện IP không đạt; đây là hành vi sẵn có.
- Khi đã dùng DDNS, một policy riêng giữ ACL đóng nếu mọi DDNS bị disable/xóa và không còn client thủ công. Để chuyển chủ đích sang auth-only/public, tạo Access List phù hợp và gán lại host; không xóa policy trong database.

## DNS và an toàn

Resolver dùng Node DNS API, không gọi shell với hostname; truy vấn A và tùy chọn AAAA, chuẩn hóa, loại trùng, tối đa 128 câu trả lời/rule và 100 rule/list. DNS chỉ cấp quyền cho IP public unicast; IP private, loopback, link-local, CGNAT, multicast và một số dải special-use bị từ chối. Một câu trả lời bị chặn làm thất bại toàn bộ lần resolve, tránh cấp quyền từ kết quả trộn public/private. Khách nội bộ tiếp tục dùng IP/CIDR thủ công.

Timeout DNS 2 giây/lần, tối đa 2 lần/family; lỗi được retry theo backoff từ interval đến tối đa 1 giờ. Scheduler đơn, không chạy chồng cùng rule. Watchdog TTL riêng kiểm tra mỗi giây, dùng chung khóa với thao tác cấu hình Nginx; DNS đang chạy hoặc thao tác Nginx đang diễn ra có thể làm việc thu hồi trễ vài giây. Trước khi Nginx khởi động, prepare hook làm rỗng các include DDNS để fail-closed; sau đó watchdog chỉ khôi phục cache còn hạn và scheduler hoạt động cùng backend. Quyền IP/CIDR thủ công và authentication không bị xóa.

Stale TTL tính từ lần resolve thành công gần nhất. TTL ngắn hơn refresh interval có thể làm quyền truy cập hết hạn giữa hai lần kiểm tra; nên đặt TTL lớn hơn interval. TTL=0 giữ kết quả thành công tối đa một refresh interval và thu hồi ngay khi resolve lỗi. Tắt Auto Refresh không tắt việc thu hồi IP stale.

DNS refresh chỉ thay file include `/data/nginx/ddns/<list-id>.conf` khi nội dung thay đổi. Thêm/sửa/xóa rule chỉ regenerate các Proxy Host đang dùng list đó. Luôn chạy `nginx -t` qua cơ chế reload NPM; lỗi sẽ khôi phục file trước đó, không xóa Proxy Host.

Nếu cấu hình Nginx khác đang lỗi, việc reload để thu hồi ACL cũng không thể thành công. Hệ thống giữ cấu hình trước, ghi `reload_failed`, retry có backoff tối đa 60 giây. Cần xử lý lỗi Nginx ngay; không thể cam kết fail-closed đúng hạn khi Nginx không reload được. Không có quy tắc `allow all` thay cho DNS lỗi.

IP WAN cũ có thể đã được cấp cho người khác trong cửa sổ stale TTL; TTL ngắn giảm cửa sổ cấp quyền nhầm nhưng tăng nguy cơ gián đoạn khi DNS lỗi.

DNS của hostname được chủ sở hữu thay đổi là nguồn ủy quyền; việc chặn IP private không bảo vệ khỏi hostname/tài khoản DNS bị chiếm quyền và trỏ sang IP public của kẻ khác.

## Build

Cần Node tương thích source NPM 2.15.1, pnpm 11.25.0, Docker/Compose. Production không cài thêm dependency backend.

```sh
./scripts/build-frontend.sh
node --test tests/*.test.mjs
docker build --network none -t local/npm:2.15.1-ddns.2 .
```

`pnpm-lock.yaml` được nhập từ yarn.lock chính thức, cài bằng `--frozen-lockfile`. CLI FormatJS được pin thiếu native darwin-x64; `scripts/compile-locales.mjs` tạo output non-AST tương đương, kiểm tra ICU bằng parser đã pin trong dependency tree (5251 message). Không đổi dependency application để xử lý thiếu binary.

## Staging

Compose ở `compose.staging.yaml`, được đặt thành `/opt/npm-ddns-staging/compose.yaml` trên server; source ở thư mục `source/` bên cạnh. Data và Let's Encrypt staging hoàn toàn riêng. Không dùng database hay SSL key production.

- HTTP proxy: server loopback `18080`.
- Admin: server loopback `18081`.
- HTTPS: server loopback `18443`.
- DNS fixture: `172.30.250.53`, chỉ trong network staging `172.30.250.0/24`.
- Trong phiên Codex hiện tại, Admin UI được forward trên `http://127.0.0.1:28083`; mật khẩu staging thử nghiệm nằm root-only tại `/opt/npm-ddns-staging/secrets/admin-password` trên server.
- App giới hạn 384 MiB/0.5 CPU; DNS 48 MiB/0.1 CPU.
- Docker log rotation đã cấu hình; history tối đa 100 sự kiện mỗi rule.
- Credential staging tạo ngẫu nhiên ở `secrets/admin-password`, quyền `0600`; không chứa trong Git hay tài liệu.

Chạy trên Debian host:

```sh
cd /opt/npm-ddns-staging
docker compose -f compose.yaml up -d
python3 source/tests/integration.py
```

Bộ integration chỉ dành cho staging này: tạo dữ liệu test riêng, thay fixture DNS, chủ động gây lỗi cấu hình staging để kiểm tra restore, và restart container **npm-ddns-staging**. Không chạy nhằm vào production.

## DNS thật sau bộ test fixture

Trước đây đã quan sát timeout khi truy vấn public DNS qua Docker stub `127.0.0.11` và DNS host `172.16.0.222`. Production DDNS hiện dùng hai resolver trực tiếp `8.8.8.8,1.1.1.1`; chỉ cấu hình resolver riêng của DDNS, không sửa DNS host/Docker/AdGuard hay firewall.

```sh
cd /opt/npm-ddns-staging
docker compose -f compose.yaml -f source/compose.real-dns.yaml up -d app
python3 source/tests/real-dns.py
```

Để chạy lại bộ fixture tests, dùng riêng `compose.yaml` với `docker compose -f compose.yaml up -d app`, sau đó chạy test. Không chạy fixture tests khi app đang dùng real-DNS override.

## Backup và rollback

Xem `ROLLBACK.md`. `scripts/backup.py` chỉ đọc production, ghi backup root-only trong `/var/backups/npm-ddns/<UTC timestamp>/`, dùng SQLite Backup API, kiểm tra integrity và tính ổn định database/cấu hình/certificate trong quá trình snapshot. Snapshot không đạt giữ nguyên marker `INCOMPLETE` để không bị dùng nhầm. Script không xóa backup cũ.

Production override thay image, thêm rotation log và đặt `DDNS_RESOLVERS=8.8.8.8,1.1.1.1` riêng cho tính năng DDNS; không thay DNS host/Docker/AdGuard. Service, ports/network/volumes/restart policy được kế thừa từ Compose gốc. Bản `.2` tự chọn DDNS khi mở Access List có sẵn DDNS rule.

## Bảo trì và nâng cấp

1. Kiểm tra NPM tag, commit và digest mới trong staging; không đổi `latest` rồi rebuild tùy tiện.
2. So sánh từng file trong `CHANGED-FILES.txt`, đặc biệt `_access.conf`, `internal/nginx.js`, routes, API schema và React AccessListModal.
3. Port thay đổi tối thiểu; giữ migration cũ và thêm migration mới khi cần.
4. Nhập lockfile chính thức tương ứng, build frontend, chạy unit/migration/integration/browser tests.
5. Diễn tập backup/restore và cutover staging về image gốc trước khi xin xác nhận production.
6. Tag custom mới rõ ràng, lưu digest và lưu lại image gốc. Không push secrets, dump, SSL key hoặc backup.

Kết quả kiểm chứng thực tế được ghi riêng trong `VALIDATION.md`; tài liệu thiết kế không thay thế bằng chứng kiểm thử.
