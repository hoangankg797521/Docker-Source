#!/bin/sh
set -eu
cd "$(dirname "$0")/.."
cd upstream/frontend
pnpm install --frozen-lockfile --ignore-scripts
cd ../..
node scripts/compile-locales.mjs
cd upstream/frontend
pnpm run build
