// Portable equivalent of FormatJS's default (non-AST) compile-folder output.
// The pinned CLI lacks a darwin-x64 native package; validate ICU using its JS parser.
import fs from 'node:fs';
import path from 'node:path';
import {pathToFileURL,fileURLToPath} from 'node:url';
const frontend=path.resolve(path.dirname(fileURLToPath(import.meta.url)),'../upstream/frontend');
const store=path.join(frontend,'node_modules/.pnpm');
const parser=fs.readdirSync(store).find(n=>n.startsWith('@formatjs+icu-messageformat-parser@'));
if(!parser)throw new Error('Install locked frontend dependencies first');
const {parse}=await import(pathToFileURL(path.join(store,parser,'node_modules/@formatjs/icu-messageformat-parser/index.js')));
const source=path.join(frontend,'src/locale/src');const target=path.join(frontend,'src/locale/lang');fs.mkdirSync(target,{recursive:true});
let count=0;
for(const name of fs.readdirSync(source).filter(n=>n.endsWith('.json'))){const json=JSON.parse(fs.readFileSync(path.join(source,name),'utf8'));const out={};for(const [key,value]of Object.entries(json)){const msg=typeof value==='string'?value:value.defaultMessage;if(typeof msg!=='string')throw new Error(name+': '+key);parse(msg);out[key]=msg;count++;}fs.writeFileSync(path.join(target,name),JSON.stringify(out));}
console.log('Locale ICU messages validated:',count);
