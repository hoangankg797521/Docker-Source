#!/usr/bin/env python3
"""Run as root on npm-prod. Only reads production; writes protected timestamped backups."""
import argparse,hashlib,json,os,shutil,sqlite3,subprocess,tarfile
from pathlib import Path
from datetime import datetime,timezone
p=argparse.ArgumentParser();p.add_argument('--container',default='nginx-proxy-manager');p.add_argument('--destination',default='/var/backups/npm-ddns');p.add_argument('--compose',default=None);a=p.parse_args()
os.umask(0o077)
def run(*args):return subprocess.check_output(args)
info=json.loads(run('docker','inspect',a.container))[0]
mounts={m['Destination']:Path(m['Source']) for m in info['Mounts']}
assert '/data' in mounts and '/etc/letsencrypt' in mounts,'Missing required mounts'
data=mounts['/data'];ssl=mounts['/etc/letsencrypt'];assert(data/'database.sqlite').exists(),'This script supports discovered SQLite deployment only'
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ');backup=Path(a.destination)/stamp;backup.mkdir(parents=True,exist_ok=False)
(backup/'INCOMPLETE').write_text('Do not restore until verification is complete.\n')
compose=Path(a.compose or info['Config']['Labels']['com.docker.compose.project.config_files'].split(',')[0]);assert compose.is_file(),'Compose file missing'
shutil.copy2(compose,backup/'docker-compose.yml');(backup/'container-inspect.json').write_text(json.dumps(info));(backup/'image-inspect.json').write_bytes(run('docker','image','inspect',info['Image']))
runtime_manifest_command=['docker','exec',a.container,'sh','-c','find /etc/nginx /app/config -type f -exec sha256sum {} +; sha256sum /etc/letsencrypt.ini']
runtime_before=sorted(run(*runtime_manifest_command).splitlines())
with (backup/'runtime-config.tar.gz').open('wb')as output:
 subprocess.run(['docker','exec',a.container,'tar','-C','/','-czf','-','etc/nginx','app/config','etc/letsencrypt.ini'],stdout=output,stderr=subprocess.PIPE,check=True)
assert sorted(run(*runtime_manifest_command).splitlines())==runtime_before,'Container runtime config changed during capture'
(backup/'runtime-config-manifest.sha256').write_bytes(b'\n'.join(runtime_before)+b'\n')
def manifest():
 out={}
 for base,label in [(data,'data'),(ssl,'letsencrypt')]:
  for root,dirs,files in os.walk(base):
   if Path(root)==data:dirs[:]=[d for d in dirs if d!='logs']
   for name in files:
    f=Path(root)/name;rel=f.relative_to(base)
    if label=='data' and name.startswith('database.sqlite'):continue
    out[label+'/'+str(rel)]=('link:'+os.readlink(f)) if f.is_symlink()else hashlib.sha256(f.read_bytes()).hexdigest()
 return out
src=sqlite3.connect('file:'+str(data/'database.sqlite')+'?mode=ro',uri=True);version=src.execute('pragma data_version').fetchone()[0];before=manifest()
dst=sqlite3.connect(str(backup/'database.sqlite'));src.backup(dst);assert dst.execute('pragma integrity_check').fetchone()[0]=='ok';dst.close()
def exclude(info):
 if info.name.startswith('data/database.sqlite'):return None
 return info
with tarfile.open(backup/'npm-volumes.tar.gz','w:gz')as tar:tar.add(data,arcname='data',filter=exclude);tar.add(ssl,arcname='letsencrypt')
assert src.execute('pragma data_version').fetchone()[0]==version,'Database changed during snapshot: preserve this backup, retry into a new timestamp'
assert manifest()==before,'Configuration or certificates changed during snapshot: preserve this backup, retry'
assert sorted(run(*runtime_manifest_command).splitlines())==runtime_before,'Container config changed during snapshot: preserve this backup, retry'
src.close()
restore=backup/'restore-check';restore.mkdir()
with tarfile.open(backup/'npm-volumes.tar.gz')as tar:tar.extractall(restore,filter='data')
shutil.copy2(backup/'database.sqlite',restore/'data/database.sqlite')
db=sqlite3.connect('file:'+str(restore/'data/database.sqlite')+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchone()[0]=='ok';db.close()
for f in ['data/nginx','data/keys.json','letsencrypt']:assert(restore/f).exists(),f
(backup/'content-manifest.json').write_text(json.dumps(before,indent=2));(backup/'SHA256SUMS').write_text(''.join(hashlib.sha256(f.read_bytes()).hexdigest()+'  '+f.name+'\n' for f in sorted(backup.iterdir())if f.is_file()and f.name!='INCOMPLETE'))
(backup/'INCOMPLETE').unlink();(backup/'VERIFIED').write_text('SQLite backup API, integrity_check, stable data_version, stable config manifest, archive extraction verified.\n')
print('BACKUP_VERIFIED',backup)
