#!/usr/bin/env python3
"""Validate a snapshot in an isolated original-image container; never mount production."""
import hashlib,json,os,shutil,sqlite3,subprocess,sys,tarfile
from pathlib import Path
from datetime import datetime,timezone
os.umask(0o077)
backup=Path(sys.argv[1]).resolve();assert backup.is_dir() and not(backup/'INCOMPLETE').exists()
for line in(backup/'SHA256SUMS').read_text().splitlines():
 digest,name=line.split(None,1);f=backup/Path(name.strip()).name;assert hashlib.sha256(f.read_bytes()).hexdigest()==digest,'Checksum mismatch: '+f.name
stamp=datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ');root=Path('/opt/npm-ddns-staging/restore-validation')/stamp;root.mkdir(parents=True,exist_ok=False)
with tarfile.open(backup/'npm-volumes.tar.gz')as t:t.extractall(root,filter='data')
shutil.copy2(backup/'database.sqlite',root/'data/database.sqlite')
(root/'data/logs').mkdir(exist_ok=True)
db=sqlite3.connect('file:'+str(root/'data/database.sqlite')+'?mode=ro',uri=True);assert db.execute('pragma integrity_check').fetchone()[0]=='ok';db.close()
image=json.loads((backup/'image-inspect.json').read_text())[0]['Id']
command=['docker','run','--rm','--pull=never','--network','none','--entrypoint','/bin/sh','--tmpfs','/data/logs','-v',str(root/'data')+':/data:ro','-v',str(root/'letsencrypt')+':/etc/letsencrypt:ro',image,'-c','useradd -o -u 0 -U -d /tmp/npm -s /bin/false npm; mkdir -p /run/nginx /tmp/nginx/body /var/log/nginx /var/lib/nginx/cache/public /var/lib/nginx/cache/private /var/cache/nginx/proxy_temp; touch /var/log/nginx/error.log; nginx -t -g "error_log stderr;"']
if (backup/'runtime-config.tar.gz').exists():
 i=command.index(image);command[i:i]=['-v',str(backup/'runtime-config.tar.gz')+':/snapshot/runtime-config.tar.gz:ro']
 command[-1]='tar -xzf /snapshot/runtime-config.tar.gz -C / && '+command[-1]
r=subprocess.run(command,capture_output=True,text=True);assert r.returncode==0,r.stderr
print('RESTORE_CHECKSUM_SQLITE_NGINX=PASS',root)
(root/'RESTORE_VERIFIED').write_text('SHA256SUMS, SQLite integrity and nginx -t passed using original image, offline with read-only snapshot mounts.\n')
