import test from 'node:test';
import assert from 'node:assert/strict';
import {exclusive} from '../upstream/backend/lib/ddns/lock.js';
test('Nginx and DNS jobs serialize and reentrant nested operations do not deadlock',async()=>{
 const order=[];
 await Promise.all([
  exclusive(async()=>{order.push('A-start');await new Promise(r=>setTimeout(r,15));await exclusive(async()=>order.push('A-inner'));order.push('A-end');}),
  exclusive(async()=>order.push('B'))
 ]);
 assert.deepEqual(order,['A-start','A-inner','A-end','B']);
});
test('failed operations release the queue',async()=>{
 await assert.rejects(exclusive(async()=>{throw new Error('expected');}));
 assert.equal(await exclusive(async()=>42),42);
});
