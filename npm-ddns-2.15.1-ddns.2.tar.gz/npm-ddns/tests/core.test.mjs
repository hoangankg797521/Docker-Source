import test from 'node:test';
import assert from 'node:assert/strict';
import {hostname,validateRule,normalize,effective,render,publicIP,lookup} from '../upstream/backend/lib/ddns/core.js';
test('hostname normalization and rejection of injection, URLs, IPs',()=>{
 assert.equal(hostname('Home.Example.COM.'),'home.example.com');
 for(const s of ['a;allow all','a.com\nallow all','https://a.com','127.0.0.1','*.a.com','a..com','-a.com','a.com/x',' a.com','a.com:80','a'.repeat(64)+'.com','123.456'])assert.throws(()=>hostname(s));
});
test('settings bounds and explicit fields',()=>{
 assert.deepEqual(validateRule({hostname:'home.example.com'}),{hostname:'home.example.com',enabled:true,ipv6:false,auto_refresh:true,refresh_interval:60,stale_ttl:300});
 for(const x of [{refresh_interval:1},{stale_ttl:-1},{enabled:'true'},{ipv6:1},{addresses:['8.8.8.8']}]) assert.throws(()=>validateRule({hostname:'home.example.com',...x}));
});
test('deduplicate and normalize multiple A/AAAA records',()=>{
 assert.deepEqual(normalize(['8.8.8.8','1.1.1.1','8.8.8.8']),['1.1.1.1','8.8.8.8']);
 assert.deepEqual(normalize(['2606:4700:4700:0000:0000:0000:0000:1111','2606:4700:4700::1111'],true),['2606:4700:4700::1111']);
 assert.throws(()=>normalize(['2606:4700::1111']));
});
test('rebinding private, loopback, mapped and reserved addresses denied',()=>{
 for(const ip of ['0.0.0.0','10.0.0.1','127.0.0.1','169.254.169.254','172.16.0.1','192.168.1.1','100.64.0.1','192.0.2.1','198.51.100.1','203.0.113.1','224.0.0.1','::1','::ffff:8.8.8.8','fc00::1','fe80::1','2001:db8::1','2002:808:808::1'])assert.equal(publicIP(ip),false,ip);
 assert.throws(()=>normalize(['8.8.8.8','10.0.0.1']));
});
const r={enabled:true,ipv6:false,last_success:100000,stale_ttl:300,addresses:'["8.8.8.8"]'};
test('DNS error retains last good until TTL, then revokes only dynamic grants',()=>{
 assert.deepEqual(effective({...r,status:'Error'},399999),['8.8.8.8']);assert.deepEqual(effective(r,400000),[]);
 assert.deepEqual(effective({...r,enabled:false},100001),[]);assert.deepEqual(effective({...r,last_success:null},100001),[]);
 assert.equal(render([r,r],100001).match(/allow /g).length,1);assert.ok(!render([r],400000).includes('allow '));
});
test('refresh replaces A by B without carrying old grant; list isolation',()=>{
 assert.match(render([r],100001),/allow 8.8.8.8;/);
 const b={...r,addresses:'["1.1.1.1"]'};assert.match(render([b],100001),/allow 1.1.1.1;/);assert.ok(!render([b],100001).includes('8.8.8.8'));
});
test('empty disabled/new rules never emit allow all or hostname',()=>{
 for(const rules of [[],[{...r,enabled:false}],[{...r,last_success:null}]]) {const c=render(rules,100001);assert.ok(!c.includes('allow all'));assert.ok(!c.includes('example'));}
});
test('zero stale TTL permits a fresh success but closes immediately on DNS failure',()=>{
 const fresh={...r,stale_ttl:0,refresh_interval:60,status:'Active'};
 assert.deepEqual(effective(fresh,100001),['8.8.8.8']);
 assert.deepEqual(effective({...fresh,status:'Error'},100001),[]);
});
