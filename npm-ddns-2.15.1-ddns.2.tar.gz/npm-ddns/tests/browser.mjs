// Isolated headless Chromium QA. Credentials arrive over stdin; never log them.
import fs from 'node:fs/promises';
import path from 'node:path';
import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
const require=createRequire(process.env.NPM_BROWSER_MODULE_ROOT||import.meta.url);
const {chromium}=require('playwright');
const input=JSON.parse(await new Promise(resolve=>{let s='';process.stdin.setEncoding('utf8');process.stdin.on('data',x=>s+=x);process.stdin.on('end',()=>resolve(s));}));
const base=input.base||'http://127.0.0.1:28081';const output=path.resolve(input.output);await fs.mkdir(output,{recursive:true});
const browser=await chromium.launch({headless:true,channel:"chrome"});const page=await browser.newPage({viewport:{width:1280,height:1100}});page.setDefaultTimeout(30000);
const errors=[];page.on('pageerror',e=>errors.push(e.name+': '+e.message.slice(0,180)));
const consoleErrors=[];page.on('console',m=>{if(m.type()==='error' && m.location().url.startsWith(base))consoleErrors.push(m.text().slice(0,180));});
const name='Browser acceptance '+Date.now();const results=[];
const record=n=>{results.push(n);console.log(n+': PASS');};
const save=async()=>{await page.getByRole('button',{name:'Save',exact:true}).click();await page.getByRole('dialog').waitFor({state:'hidden',timeout:90000});};
const edit=async()=>{
 await page.locator('#advanced-table-search').fill(name);
 const row=page.getByRole('row').filter({hasText:name});await row.locator('button.dropdown-toggle').click();await row.getByRole('link',{name:'Edit',exact:true}).click();
 await page.getByRole('tab',{name:'Rules',exact:true}).click();await page.locator('#rule-type').waitFor();await page.waitForFunction(()=>document.querySelector('#rule-type')?.value==='ddns');
};
try{
 await page.goto(base+'/');await page.getByLabel('Email address',{exact:true}).fill(input.email);await page.getByPlaceholder('Password',{exact:true}).fill(input.password);await page.getByRole('button',{name:'Sign in',exact:true}).click();
 await page.getByRole('heading',{name:'Login to your account',exact:true}).waitFor({state:'hidden',timeout:60000});record('Browser login');
 await page.goto(base+'/access');await page.getByRole('button',{name:'Add Access List',exact:true}).click();
 await page.getByRole('textbox',{name:'Name',exact:true}).fill(name);await page.getByRole('tab',{name:'Rules',exact:true}).click();
 await page.locator('#rule-type').selectOption('ddns');await page.getByRole('button',{name:'Add DDNS Rule',exact:true}).click();await page.getByLabel('Hostname',{exact:true}).fill('browser.example.test');await save();record('Create DDNS-only list through UI');
 await edit();await page.getByLabel('Hostname',{exact:true}).waitFor();assert.equal(await page.getByLabel('Hostname',{exact:true}).inputValue(),'browser.example.test');
 await page.getByRole('button',{name:'Refresh DNS Now',exact:true}).click();await page.getByRole('button',{name:'Refresh DNS Now',exact:true}).waitFor({state:'visible'});
 await page.getByText('DDNS / Active',{exact:false}).waitFor({timeout:30000});record('Resolved IPv4 and Active status through UI');
 await page.getByRole('button',{name:'View History',exact:true}).click();await page.getByRole('button',{name:'Close History',exact:true}).waitFor();await page.getByRole('button',{name:'Close History',exact:true}).click();record('Refresh and history controls');
 await page.getByLabel('Refresh interval (seconds)',{exact:true}).fill('90');await save();await edit();await page.getByLabel('Hostname',{exact:true}).waitFor();assert.equal(await page.getByLabel('Refresh interval (seconds)',{exact:true}).inputValue(),'90');record('Edit and persist DDNS settings through UI');
 await page.getByText('Access List has been saved',{exact:true}).first().waitFor({state:'hidden',timeout:15000});
 await page.screenshot({path:path.join(output,'staging-desktop.png'),fullPage:true});
 await page.setViewportSize({width:390,height:1000});await page.getByLabel('Hostname',{exact:true}).scrollIntoViewIfNeeded();
 const bounds=await page.getByRole('dialog').evaluate(e=>({client:e.clientWidth,scroll:e.scrollWidth}));assert.ok(bounds.scroll<=bounds.client+1,JSON.stringify(bounds));await page.screenshot({path:path.join(output,'staging-mobile.png'),fullPage:true});record('Mobile 390px layout has no horizontal overflow');
 await page.setViewportSize({width:1280,height:1100});await page.getByRole('button',{name:'Delete DDNS Rule',exact:true}).click();await save();await edit();await page.getByRole('button',{name:'Add DDNS Rule',exact:true}).waitFor();assert.equal(await page.getByLabel('Hostname',{exact:true}).count(),0);record('Delete last DDNS rule through UI');
 await page.getByRole('button',{name:'Cancel',exact:true}).click();
 assert.deepEqual(errors,[]);assert.deepEqual(consoleErrors,[]);record('No application page or console errors');
 await fs.writeFile(path.join(output,'browser-results.json'),JSON.stringify({result:'PASS',results,errors,consoleErrors,listName:name},null,2));
}catch(e){await fs.writeFile(path.join(output,'browser-error.txt'),e.name+': '+e.message.replaceAll(input.password,'[REDACTED]').slice(0,2000));throw new Error('Browser QA failed; see sanitized browser-error.txt');}
finally{await browser.close();}
