"""Run on the Debian host against the isolated npm-ddns-staging project only."""
import base64,json,os,secrets,subprocess,time,urllib.request,urllib.error
from pathlib import Path
ROOT=Path('/opt/npm-ddns-staging'); API='http://127.0.0.1:18081/api'; TOKEN=None
results=[]
def record(name,detail='PASS'):
 results.append({'test':name,'result':detail});print(name+': '+detail,flush=True)
def api(method,path,data=None,token='default',expect=(200,201)):
 headers={'Content-Type':'application/json'}
 t=TOKEN if token=='default' else token
 if t:headers['Authorization']='Bearer '+t
 req=urllib.request.Request(API+path,data=json.dumps(data).encode() if data is not None else None,headers=headers,method=method)
 try:
  with urllib.request.urlopen(req,timeout=30)as res:code=res.status;body=res.read()
 except urllib.error.HTTPError as e:code=e.code;body=e.read()
 assert code in expect,(method,path,code,body[:150].decode(errors='replace'))
 return json.loads(body) if body else None

def fixture(config):
 p=ROOT/'fixtures/dns.json';tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(config));tmp.replace(p)
def probe(host,ip=None,auth=None,xff=None):
 headers={'Host':host}
 if ip:headers['X-Real-IP']=ip
 if xff:headers['X-Forwarded-For']=xff
 if auth:headers['Authorization']='Basic '+base64.b64encode(auth.encode()).decode()
 req=urllib.request.Request('http://127.0.0.1:18080/',headers=headers)
 try:
  with urllib.request.urlopen(req,timeout=10)as r:return r.status
 except urllib.error.HTTPError as e:return e.code

def expect_probe(host,ip=None,auth=None,xff=None,expected=200):
 for _ in range(25):
  try:
   if probe(host,ip,auth,xff)==expected:return True
  except (OSError,urllib.error.URLError):pass
  time.sleep(0.2)
 return False

def shell(*args):return subprocess.check_output(args,text=True,stderr=subprocess.DEVNULL).strip()
def rules(lid):return api('GET',f'/nginx/access-lists/{lid}/ddns')
def refresh(lid,rid,expect=(200,201)):return api('POST',f'/nginx/access-lists/{lid}/ddns/{rid}/refresh',{},expect=expect)
def create_acl(name,clients=None,ddns=None,items=None,satisfy=False):
 result=api('POST','/nginx/access-lists',{'name':name,'satisfy_any':satisfy,'pass_auth':False,'items':items or [],'clients':clients or [],**({'ddns_rules':ddns} if ddns is not None else {})})
 if ddns:
  for _ in range(240):
   if all(r['status']!='Updating' or not r['enabled'] for r in rules(result['id'])):break
   time.sleep(.25)
  else:raise AssertionError('Initial DNS job did not finish')
 return result
def create_host(name,lid):
 return api('POST','/nginx/proxy-hosts',{'domain_names':[name],'forward_scheme':'http','forward_host':'127.0.0.1','forward_port':81,'access_list_id':lid,'certificate_id':0,'ssl_forced':False,'locations':[]})
def include(lid):return(ROOT/f'state/data/nginx/ddns/{lid}.conf').read_text()
def reload_count(lid):
 count=0
 for line in shell('docker','logs','npm-ddns-staging').splitlines():
  try:event=json.loads(line)
  except (ValueError,TypeError):continue
  if event.get('event')=='reload_success' and event.get('access_list_id')==lid:count+=1
 return count

password=(ROOT/'secrets/admin-password').read_text().strip()
for i in range(240):
 try:TOKEN=api('POST','/tokens',{'identity':'staging@example.test','secret':password},token=None)['token'];break
 except Exception:
  if i==239:raise
  time.sleep(1)
run=str(int(time.time()));domain='ddns-'+run+'.example.test';second='second-'+run+'.example.test'
# Invalid whole-list DDNS payloads must be rejected before legacy ACL creation/update.
base_acl_count=len(api('GET','/nginx/access-lists'))
for invalid_rules in ([{'hostname':'dup.example.test'},{'hostname':'DUP.example.test'}], [{'hostname':'bad.test;allow all'}], [{'id':999999,'hostname':'foreign.example.test'}]):
 api('POST','/nginx/access-lists',{'name':'Invalid DDNS '+secrets.token_hex(6),'satisfy_any':False,'pass_auth':False,'items':[],'clients':[],'ddns_rules':invalid_rules},expect=(400,))
assert len(api('GET','/nginx/access-lists'))==base_acl_count
config={domain:{'a':['8.8.8.8','1.1.1.1','8.8.8.8']},second:{'a':['9.9.9.9']}}
fixture(config)
manual=[{'directive':'allow','address':'14.161.49.22'},{'directive':'allow','address':'115.77.96.0/24'}]
acl=create_acl('DDNS acceptance '+run,manual,[{'hostname':domain,'stale_ttl':300}]);lid=acl['id'];r=rules(lid)[0];rid=r['id']
api('PUT',f'/nginx/access-lists/{lid}',{'name':'Invalid update must preserve ACL','ddns_rules':[{'id':999999,'hostname':'foreign.example.test'}]},expect=(400,))
assert api('GET',f'/nginx/access-lists/{lid}')['name']=='DDNS acceptance '+run and rules(lid)[0]['id']==rid
record('Invalid whole-ACL DDNS payloads do not create or modify legacy ACLs')
assert json.loads(r['addresses'])==['1.1.1.1','8.8.8.8'];assert r['status']=='Active';record('A records, normalization and persistence')
host='test-'+run+'.example.test';h=create_host(host,lid)
assert expect_probe(host,'14.161.49.22', expected=200);assert expect_probe(host,'115.77.96.19', expected=200);assert expect_probe(host,'9.9.9.9', expected=403)
record('Existing manual IP and CIDR allow/deny through HTTP')
assert expect_probe(host,'8.8.8.8', expected=200);assert expect_probe(host,'1.1.1.1', expected=200);record('DDNS effective allow through HTTP')
count=reload_count(lid);mtime=(ROOT/f'state/data/nginx/ddns/{lid}.conf').stat().st_mtime_ns;refresh(lid,rid);assert reload_count(lid)==count;assert (ROOT/f'state/data/nginx/ddns/{lid}.conf').stat().st_mtime_ns==mtime;record('Unchanged DNS does not reload Nginx')
config[domain]={'a':['4.2.2.2']};fixture(config);refresh(lid,rid)
assert expect_probe(host,'4.2.2.2', expected=200);assert expect_probe(host,'8.8.8.8', expected=403);assert expect_probe(host,'14.161.49.22', expected=200);record('A to B change revokes A, permits B, preserves manual rule')
acl2=create_acl('Isolated list '+run,ddns=[{'hostname':second,'stale_ttl':300}]);lid2=acl2['id'];host2='second-host-'+run+'.example.test';create_host(host2,lid2)
assert expect_probe(host2,'9.9.9.9', expected=200);assert expect_probe(host2,'4.2.2.2', expected=403);record('Multiple Access Lists remain isolated')
# NXDOMAIN: retain stale addresses briefly, then independently enforce TTL.
api('PUT',f'/nginx/access-lists/{lid}/ddns/{rid}',{'hostname':domain,'stale_ttl':15});refresh(lid,rid);config[domain]={'error':'NXDOMAIN'};fixture(config);rr=refresh(lid,rid);assert rr['status']=='Error';assert '4.2.2.2' in include(lid)
time.sleep(16);assert expect_probe(host,'4.2.2.2', expected=403);assert expect_probe(host,'14.161.49.22', expected=200);record('NXDOMAIN stale TTL and fail-closed preserve manual entries')
# Recovery then timeout: measured bounded retry duration.
config[domain]={'a':['4.2.2.2']};fixture(config);refresh(lid,rid);config[domain]={'error':'TIMEOUT'};fixture(config);start=time.monotonic();rr=refresh(lid,rid);assert rr['status']=='Error';assert time.monotonic()-start<15;time.sleep(16);assert expect_probe(host,'4.2.2.2', expected=403);record('DNS timeout is bounded and grants expire')
# DNS rebinding cannot grant a private client.
config[domain]={'a':['10.10.10.10']};fixture(config);rr=refresh(lid,rid);assert rr['status']=='Error';assert '10.10.10.10' not in include(lid);record('DNS private-address policy / rebinding')
for bad in ['x.test;allow all','http://bad.test','a.test\nallow all','127.0.0.1']:
 api('POST',f'/nginx/access-lists/{lid}/ddns',{'hostname':bad},expect=(400,))
api('POST',f'/nginx/access-lists/{lid}/ddns',{'hostname':'unused.example.test','enabled':'true'},expect=(400,))
api('GET',f'/nginx/access-lists/{lid}/ddns',token=None,expect=(401,403))
other_pass=secrets.token_urlsafe(24)
api('POST','/users',{'name':'DDNS limited test','nickname':'limited','email':'limited-'+run+'@example.test','roles':[],'auth':{'type':'password','secret':other_pass}})
limited=api('POST','/tokens',{'identity':'limited-'+run+'@example.test','secret':other_pass},token=None)['token']
api('GET',f'/nginx/access-lists/{lid}/ddns',token=limited,expect=(403,404))
api('POST',f'/nginx/access-lists/{lid}/ddns',{'hostname':second},token=limited,expect=(403,404))
api('POST',f'/nginx/access-lists/{lid}/ddns/{rules(lid2)[0]["id"]}/refresh',{},expect=(404,))
record('Input validation, unauthenticated access, owner isolation and cross-list IDs')
# Authentication semantics: satisfy all requires both ACL match and credentials.
auth_pass=secrets.token_urlsafe(20)
auth_acl=create_acl('Auth regression '+run,manual,items=[{'username':'acluser','password':auth_pass}]);auth_host='auth-'+run+'.example.test';create_host(auth_host,auth_acl['id'])
assert expect_probe(auth_host,'14.161.49.22', expected=401);assert expect_probe(auth_host,'14.161.49.22','acluser:'+auth_pass, expected=200);assert expect_probe(auth_host,'8.8.4.4','acluser:'+auth_pass, expected=403)
record('Basic authentication and satisfy all preserved')
# A custom config syntax error must restore files and never reload invalid config.
config[domain]={'a':['4.2.2.2']};fixture(config);api('PUT',f'/nginx/access-lists/{lid}/ddns/{rid}',{'hostname':domain,'stale_ttl':300});refresh(lid,rid);assert expect_probe(host,'4.2.2.2',expected=200);before=include(lid)
custom=ROOT/'state/data/nginx/custom/http_top.conf';custom.parent.mkdir(parents=True,exist_ok=True);assert not custom.exists();custom.write_text('invalid_ddns_test;\n')
try:
 config[domain]={'a':['8.8.4.4']};fixture(config);refresh(lid,rid,expect=(400,));assert include(lid)==before;assert expect_probe(host,'4.2.2.2', expected=200)
finally:custom.unlink()
refresh(lid,rid);assert expect_probe(host,'8.8.4.4', expected=200);record('Invalid Nginx configuration rolls back files; previous worker keeps serving')
# XFF spoofing is ignored; X-Real-IP is honored only due inherited private trust ranges.
assert expect_probe(host,None,xff='8.8.4.4', expected=403)
assert expect_probe(host,'8.8.4.4', expected=200)
record('Source IP behavior','PASS: XFF ignored; inherited private-peer X-Real-IP trust verified (deployment review required)')
# Disable/delete the final DDNS rule must keep a DDNS-only list closed.
r2=rules(lid2)[0];api('PUT',f'/nginx/access-lists/{lid2}/ddns/{r2["id"]}',{'hostname':second,'enabled':False});assert expect_probe(host2,'9.9.9.9', expected=403)
api('DELETE',f'/nginx/access-lists/{lid2}/ddns/{r2["id"]}');assert rules(lid2)==[];assert expect_probe(host2,'9.9.9.9', expected=403);record('Disable and delete last DDNS rule stay fail-closed')
# Use a longer TTL while testing restart and scheduler.
api('PUT',f'/nginx/access-lists/{lid}/ddns/{rid}',{'hostname':domain,'refresh_interval':60,'stale_ttl':300})
started=shell('docker','inspect','npm-ddns-staging','--format','{{.State.StartedAt}}');shell('docker','restart','npm-ddns-staging')
for i in range(240):
 try:assert rules(lid)[0]['id']==rid;break
 except Exception:
  if i==239:raise
  time.sleep(1)
assert started!=shell('docker','inspect','npm-ddns-staging','--format','{{.State.StartedAt}}');assert expect_probe(host,'8.8.4.4', expected=200)
record('Container restart retains rules and rehydrates Nginx')
config[domain]={'a':['1.0.0.1']};fixture(config);deadline=time.monotonic()+75
while time.monotonic()<deadline:
 if '1.0.0.1' in include(lid):break
 time.sleep(2)
else:raise AssertionError('Scheduler did not refresh DNS within 75 seconds')
assert expect_probe(host,'1.0.0.1', expected=200);assert expect_probe(host,'8.8.4.4', expected=403);record('Scheduler auto-refresh after restart without further container restart')
history=api('GET',f'/nginx/access-lists/{lid}/ddns/{rid}/history');assert any(h['event']=='resolution_failed' for h in history);record('DNS history is persisted and readable')
shell('docker','exec','npm-ddns-staging','nginx','-t');record('Final staging nginx -t')
(ROOT/'integration-results.json').write_text(json.dumps({'results':results,'access_list_id':lid,'rule_id':rid,'host':host},indent=2))
print('ALL_INTEGRATION_TESTS_PASSED',len(results),flush=True)
