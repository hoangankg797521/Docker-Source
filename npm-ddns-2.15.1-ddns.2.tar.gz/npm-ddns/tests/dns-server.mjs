import dgram from 'node:dgram';
import fs from 'node:fs';
const server=dgram.createSocket('udp4');
server.on('message',(msg,peer)=>{
 try {
  let i=12;const parts=[];while(msg[i]){const n=msg[i++];parts.push(msg.subarray(i,i+n).toString());i+=n;}i++;
  const kind=msg.readUInt16BE(i);const end=i+4;const name=parts.join('.');
  const config=JSON.parse(fs.readFileSync('/fixtures/dns.json','utf8'));const rule=config[name]||{error:'NXDOMAIN'};
  if(rule.error==='TIMEOUT')return;
  const addresses=rule.error?[]:(kind===1?rule.a||[]:kind===28?rule.aaaa||[]:[]);
  const header=Buffer.alloc(12);msg.copy(header,0,0,2);header.writeUInt16BE(rule.error?0x8183:0x8180,2);header.writeUInt16BE(1,4);header.writeUInt16BE(addresses.length,6);
  const answers=addresses.map(ip=>{
   let bytes;if(kind===1)bytes=Buffer.from(ip.split('.').map(Number));else{const sections=ip.split('::');let groups=sections[0]?sections[0].split(':'):[];const right=sections[1]?sections[1].split(':'):[];if(sections.length===2)groups=[...groups,...Array(8-groups.length-right.length).fill('0'),...right];bytes=Buffer.alloc(16);groups.forEach((v,k)=>bytes.writeUInt16BE(parseInt(v,16),2*k));}
   const h=Buffer.alloc(12);h.writeUInt16BE(0xc00c,0);h.writeUInt16BE(kind,2);h.writeUInt16BE(1,4);h.writeUInt32BE(1,6);h.writeUInt16BE(bytes.length,10);return Buffer.concat([h,bytes]);
  });
  server.send(Buffer.concat([header,msg.subarray(12,end),...answers]),peer.port,peer.address);
 }catch(e){console.error('DNS_FIXTURE_ERROR',e.code||e.name);}
});
server.bind(53,'0.0.0.0');
