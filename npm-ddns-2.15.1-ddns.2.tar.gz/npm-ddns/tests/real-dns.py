"""Full API -> public DNS -> Nginx ACL check; staging only, after real-DNS override."""
import json,time,urllib.request,urllib.error
from pathlib import Path
root=Path('/opt/npm-ddns-staging');token=None

def api(method,path,data=None):
 headers={'Content-Type':'application/json'}
 if token:headers['Authorization']='Bearer '+token
 req=urllib.request.Request('http://127.0.0.1:18081/api'+path,headers=headers,method=method,data=json.dumps(data).encode()if data is not None else None)
 with urllib.request.urlopen(req,timeout=30)as r:return json.load(r)
for i in range(240):
 try:token=api('POST','/tokens',{'identity':'staging@example.test','secret':(root/'secrets/admin-password').read_text().strip()})['token'];break
 except Exception:
  if i==239:raise
  time.sleep(1)
a=api('POST','/nginx/access-lists',{'name':'Real DNS acceptance '+str(int(time.time())),'satisfy_any':False,'pass_auth':False,'clients':[],'items':[],'ddns_rules':[{'hostname':'one.one.one.one'}]})
for _ in range(200):
 r=api('GET',f'/nginx/access-lists/{a["id"]}/ddns')[0]
 if r['status']=='Active':break
 if r['status']=='Error':raise AssertionError('Real DNS failed: '+str(r['error']))
 time.sleep(.25)
else:raise AssertionError('DNS job did not complete')
ips=json.loads(r['addresses']);assert ips and all(':'not in ip for ip in ips)
name='real-dns-'+str(int(time.time()))+'.example.test'
api('POST','/nginx/proxy-hosts',{'domain_names':[name],'forward_scheme':'http','forward_host':'127.0.0.1','forward_port':81,'access_list_id':a['id'],'certificate_id':0,'ssl_forced':False,'locations':[]})
def probe(ip):
 try:
  with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:18080/',headers={'Host':name,'X-Real-IP':ip}),timeout=10)as response:return response.status
 except urllib.error.HTTPError as error:return error.code
for _ in range(50):
 if probe(ips[0])==200 and probe('9.9.9.9')==403:break
 time.sleep(.2)
else:raise AssertionError('Real DNS result was not enforced by Nginx')
result={'result':'PASS','resolvers':'8.8.8.8,1.1.1.1','hostname':'one.one.one.one','ipv4_records':ips,'api_resolution_status':r['status'],'http_allowed':200,'http_denied':403,'scope':'staging API and Nginx; synthetic client source, real public DNS; production unchanged'}
(root/'real-dns-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
