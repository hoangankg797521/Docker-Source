"""Verify active proxy connections and Satisfy Any on isolated staging only."""
import base64,json,secrets,subprocess,threading,time,urllib.request,urllib.error
from pathlib import Path
root=Path('/opt/npm-ddns-staging');token=None

def api(method,path,data=None):
 headers={'Content-Type':'application/json'}
 if token:headers['Authorization']='Bearer '+token
 req=urllib.request.Request('http://127.0.0.1:18081/api'+path,headers=headers,method=method,data=json.dumps(data).encode()if data is not None else None)
 with urllib.request.urlopen(req,timeout=30)as r:return json.load(r)
token=api('POST','/tokens',{'identity':'staging@example.test','secret':(root/'secrets/admin-password').read_text().strip()})['token']
name='stream-'+str(int(time.time()))+'.example.test';fixture=root/'fixtures/dns.json';config=json.loads(fixture.read_text());config[name]={'a':['8.8.8.8']};fixture.write_text(json.dumps(config))
password=secrets.token_urlsafe(24)
acl=api('POST','/nginx/access-lists',{'name':'Graceful reload '+name,'satisfy_any':True,'pass_auth':False,'items':[{'username':'teststream','password':password}],'clients':[{'directive':'allow','address':'14.161.49.22'}],'ddns_rules':[{'hostname':name}]})
backend='npm-ddns-stream-fixture';server='const http=require("node:http");http.createServer((req,res)=>{res.writeHead(200,{"Content-Type":"application/octet-stream","Cache-Control":"no-store","X-Accel-Buffering":"no"});let n=0;const timer=setInterval(()=>{res.write(Buffer.alloc(4096,65));if(++n===64){clearInterval(timer);res.end();}},100);res.on("close",()=>clearInterval(timer));}).listen(8080,"0.0.0.0");'
subprocess.run(['docker','run','-d','--rm','--name',backend,'--network','npm-ddns-staging_default','--memory','48m','--cpus','0.10','--entrypoint','node','jc21/nginx-proxy-manager@sha256:52b2c59994f3d36acfcf70a1626f29734df0ed8c71bacc0269f78b6f939858bb','-e',server],check=True,stdout=subprocess.DEVNULL)
try:
 ip=json.loads(subprocess.check_output(['docker','inspect',backend]))[0]['NetworkSettings']['Networks']['npm-ddns-staging_default']['IPAddress']
 host=api('POST','/nginx/proxy-hosts',{'domain_names':[name],'forward_scheme':'http','forward_host':ip,'forward_port':8080,'access_list_id':acl['id'],'certificate_id':0,'ssl_forced':False,'locations':[]})
 def probe(ip,auth=None):
  headers={'Host':name,'X-Real-IP':ip}
  if auth:headers['Authorization']='Basic '+base64.b64encode(('teststream:'+auth).encode()).decode()
  try:
   with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:18080/',headers=headers),timeout=15)as r:return r.status
  except urllib.error.HTTPError as e:return e.code
 for _ in range(30):
  if probe('9.9.9.9')==401:break
  time.sleep(.2)
 assert probe('9.9.9.9',password)==200;assert probe('14.161.49.22')==200
 print('Satisfy Any: valid auth OR allowed IP passes; neither is rejected: PASS',flush=True)
 rule=api('GET',f'/nginx/access-lists/{acl["id"]}/ddns')[0];errors=[]
 def change():
  try:
   time.sleep(.5);j=json.loads(fixture.read_text());j[name]={'a':['1.0.0.1']};fixture.write_text(json.dumps(j));api('POST',f'/nginx/access-lists/{acl["id"]}/ddns/{rule["id"]}/refresh',{})
  except Exception as e:errors.append(type(e).__name__)
 headers={'Host':name,'X-Real-IP':'14.161.49.22'}
 with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:18080/',headers=headers),timeout=20)as response:
  first=response.read(4096);thread=threading.Thread(target=change);thread.start();body=first+response.read();thread.join()
 assert not errors,errors;assert body==b'A'*(4096*64);assert '1.0.0.1'in(root/f'state/data/nginx/ddns/{acl["id"]}.conf').read_text()
 print('Active 256 KiB streamed response survived DDNS-triggered Nginx reload: PASS',flush=True)
 result={'result':'PASS','satisfy_any':'PASS','active_connection_during_reload':'PASS','response_bytes':len(body),'scope':'staging synthetic source addresses; no production change'}
 (root/'graceful-results.json').write_text(json.dumps(result,indent=2))
finally:
 if 'host' in locals():api('DELETE',f'/nginx/proxy-hosts/{host["id"]}')
 subprocess.run(['docker','stop',backend],check=True,stdout=subprocess.DEVNULL)
