"""Prove expired cached grants are closed at the FIRST HTTP response after boot."""
import json,sqlite3,subprocess,time,urllib.request,urllib.error
from pathlib import Path
root=Path('/opt/npm-ddns-staging');token=None

def api(method,path,data=None):
 headers={'Content-Type':'application/json'}
 if token:headers['Authorization']='Bearer '+token
 req=urllib.request.Request('http://127.0.0.1:18081/api'+path,headers=headers,method=method,data=json.dumps(data).encode()if data is not None else None)
 with urllib.request.urlopen(req,timeout=30)as r:return json.load(r)
token=api('POST','/tokens',{'identity':'staging@example.test','secret':(root/'secrets/admin-password').read_text().strip()})['token']
name='startup-'+str(int(time.time()))+'.example.test';p=root/'fixtures/dns.json';fixture=json.loads(p.read_text());fixture[name]={'a':['8.8.8.8']};p.write_text(json.dumps(fixture))
a=api('POST','/nginx/access-lists',{'name':'Startup stale-cache acceptance '+name,'satisfy_any':False,'pass_auth':False,'items':[],'clients':[{'directive':'allow','address':'14.161.49.22'}],'ddns_rules':[{'hostname':name,'auto_refresh':False,'stale_ttl':300}]})
for _ in range(240):
 rule=api('GET',f'/nginx/access-lists/{a["id"]}/ddns')[0]
 if rule['status']=='Active':break
 time.sleep(.25)
else:raise AssertionError('Initial DNS did not complete')
api('POST','/nginx/proxy-hosts',{'domain_names':[name],'forward_scheme':'http','forward_host':'127.0.0.1','forward_port':81,'access_list_id':a['id'],'certificate_id':0,'ssl_forced':False,'locations':[]})

def probe(ip):
 try:
  with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:18080/',headers={'Host':name,'X-Real-IP':ip}),timeout=2)as r:return r.status
 except urllib.error.HTTPError as e:return e.code
for _ in range(50):
 if probe('8.8.8.8')==200:break
 time.sleep(.2)
else:raise AssertionError('Grant did not apply before restart')
subprocess.run(['docker','stop','npm-ddns-staging'],check=True,stdout=subprocess.DEVNULL)
# Only this disposable staging database is changed, while its container is stopped.
dbpath=root/'state/data/database.sqlite';assert str(dbpath).startswith('/opt/npm-ddns-staging/state/')
db=sqlite3.connect(dbpath);db.execute('update access_list_ddns set last_success=?,status=?,error=? where id=?',(int(time.time()*1000)-3600000,'Error','SIMULATED_OFFLINE_EXPIRY',rule['id']));db.commit();db.close()
assert 'allow 8.8.8.8;'in(root/f'state/data/nginx/ddns/{a["id"]}.conf').read_text()
started=time.monotonic();subprocess.run(['docker','start','npm-ddns-staging'],check=True,stdout=subprocess.DEVNULL)
first=None
for _ in range(900):
 try:first=probe('8.8.8.8');break
 except (OSError,urllib.error.URLError):time.sleep(.2)
assert first==403,('Stale grant visible at first HTTP response',first)
assert probe('14.161.49.22')==200
try:
 with urllib.request.urlopen('http://127.0.0.1:18081/api/',timeout=2)as r:api_ready=r.status==200
except Exception:api_ready=False
result={'result':'PASS','expired_ddns_first_http_status':first,'manual_rule_http_status':200,'backend_api_ready_at_first_response':api_ready,'first_proxy_response_seconds':round(time.monotonic()-started,2),'scope':'staging only; offline interval simulated in stopped staging SQLite'}
(root/'startup-results.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
# Leave the subsequent test a ready API rather than only an early Nginx response.
for i in range(180):
 try:api('GET','/');break
 except Exception:
  if i==179:raise
  time.sleep(1)
