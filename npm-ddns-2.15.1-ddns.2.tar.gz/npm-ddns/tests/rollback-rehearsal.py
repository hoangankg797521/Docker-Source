"""Offline full image/database rollback rehearsal, using protected backup copies only."""
import json,os,shutil,sqlite3,subprocess,sys,tarfile,time
from pathlib import Path
from datetime import datetime,timezone
os.umask(0o077)
backup=Path(sys.argv[1]).resolve();assert not(backup/'INCOMPLETE').exists()
root=Path('/opt/npm-ddns-staging/rollback-rehearsal')/datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ');root.mkdir(parents=True)
name='npm-ddns-rollback-check';original=json.loads((backup/'image-inspect.json').read_text())[0]['Id'];custom='local/npm:2.15.1-ddns.2'

def unpack():
 state=root/'state';state.mkdir()
 with tarfile.open(backup/'npm-volumes.tar.gz')as t:t.extractall(state,filter='data')
 shutil.copy2(backup/'database.sqlite',state/'data/database.sqlite');return state

def run(*args):return subprocess.run(args,capture_output=True,text=True,check=True).stdout

def start(image):
 state=root/'state';t=time.monotonic()
 command=['docker','run','-d','--pull=never','--name',name,'--network','none','--memory','320m','--cpus','0.50','-e','IP_RANGES_FETCH_ENABLED=false','--log-opt','max-size=1m','--log-opt','max-file=2','-v',str(state/'data')+':/data','-v',str(state/'letsencrypt')+':/etc/letsencrypt']
 if (backup/'runtime-config.tar.gz').exists():command+=['-v',str(backup/'runtime-config.tar.gz')+':/snapshot/runtime-config.tar.gz:ro','--entrypoint','/bin/sh',image,'-c','tar -xzf /snapshot/runtime-config.tar.gz -C / && exec /init']
 else:command+=[image]
 run(*command)
 for _ in range(180):
  p=subprocess.run(['docker','exec',name,'node','-e','fetch("http://127.0.0.1:3000/").then(r=>{if(!r.ok)process.exit(1);return r.json()}).then(j=>{if(j.status!=="OK")process.exit(1)}).catch(()=>process.exit(1))'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
  if p.returncode==0:break
  time.sleep(1)
 else:raise RuntimeError('Offline rehearsal backend not ready')
 run('docker','exec',name,'nginx','-t');return round(time.monotonic()-t,2)

def stop():run('docker','stop',name);run('docker','rm',name)

unpack();started=False
try:
 upgrade_seconds=start(custom);started=True
 db=sqlite3.connect(root/'state/data/database.sqlite');assert db.execute("select count(*) from sqlite_master where name='access_list_ddns'").fetchone()[0]==1;db.close()
 stop();started=False;(root/'state').rename(root/'custom-state-preserved')
 unpack();rollback_seconds=start(original);started=True
 db=sqlite3.connect(root/'state/data/database.sqlite');before=sqlite3.connect('file:'+str(backup/'database.sqlite')+'?mode=ro',uri=True)
 for table in ['access_list','access_list_client','access_list_auth','proxy_host','certificate','redirection_host','stream']:
  assert db.execute('select * from '+table+' order by id').fetchall()==before.execute('select * from '+table+' order by id').fetchall(),table
 assert db.execute("select count(*) from sqlite_master where name='access_list_ddns'").fetchone()[0]==0
 assert db.execute('pragma integrity_check').fetchone()[0]=='ok';db.close();before.close()
 result={'result':'PASS','upgrade_startup_seconds':upgrade_seconds,'rollback_startup_seconds':rollback_seconds,'network':'none','published_ports':[],'production_modified':False,'database_restored':'pre-migration snapshot; original table rows compared','path':str(root)}
 (root/'RESULT.json').write_text(json.dumps(result,indent=2));print(json.dumps(result))
finally:
 if started:stop()
