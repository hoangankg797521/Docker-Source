import assert from 'node:assert/strict';
import {createRequire} from 'node:module';
import {up,down} from '../upstream/backend/migrations/20261016070000_ddns_access.js';
const require=createRequire('/app/package.json');const knex=require('knex')({client:'better-sqlite3',connection:{filename:'/testdb/database.sqlite'},useNullAsDefault:true});
try {
 const original=await knex.raw("SELECT name,sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name");
 const tables=['access_list','access_list_client','access_list_auth','proxy_host','certificate','redirection_host','stream'];
 const before={};for(const t of tables)before[t]=await knex(t).select('*');
 for(let i=0;i<2;i++){
  await up(knex);assert.ok(await knex.schema.hasTable('access_list_ddns'));await down(knex);
  assert.deepEqual(await knex.raw("SELECT name,sql FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%' ORDER BY name"),original);
  for(const t of tables)assert.deepEqual(await knex(t).select('*'),before[t]);
 }
 assert.equal((await knex.raw('PRAGMA integrity_check'))[0].integrity_check,'ok');
 console.log('MIGRATION_UP_DOWN_TWICE=PASS; original tables and all rows unchanged; integrity_check=ok');
}finally{await knex.destroy();}
