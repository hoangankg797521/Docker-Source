"""Slow initial DNS batches must not hold the HTTP lock across network queries."""
import json,time,urllib.request
from pathlib import Path
root=Path('/opt/npm-ddns-staging');token=None

def api(method,path,data=None):
 headers={'Content-Type':'application/json'}
 if token:headers['Authorization']='Bearer '+token
 req=urllib.request.Request('http://127.0.0.1:18081/api'+path,headers=headers,method=method,data=json.dumps(data).encode()if data is not None else None)
 with urllib.request.urlopen(req,timeout=30)as r:return json.load(r)
token=api('POST','/tokens',{'identity':'staging@example.test','secret':(root/'secrets/admin-password').read_text().strip()})['token']
run=str(int(time.time()));good='ttl-'+run+'.example.test';slow=['timeout-'+str(i)+'-'+run+'.example.test'for i in range(3)]
p=root/'fixtures/dns.json';fixture=json.loads(p.read_text());fixture[good]={'a':['8.8.8.8']}
for n in slow:fixture[n]={'error':'TIMEOUT'}
p.write_text(json.dumps(fixture))
def create(name,rules):return api('POST','/nginx/access-lists',{'name':name+' '+run,'satisfy_any':False,'pass_auth':False,'items':[],'clients':[],'ddns_rules':rules})
a=create('TTL watchdog independent',[{'hostname':good,'auto_refresh':False,'stale_ttl':8}])
for _ in range(150):
 r=api('GET',f'/nginx/access-lists/{a["id"]}/ddns')[0]
 if r['status']=='Active' and '8.8.8.8'in(root/f'state/data/nginx/ddns/{a["id"]}.conf').read_text():break
 time.sleep(.2)
else:raise AssertionError('Initial DNS did not complete')
assert '8.8.8.8'in(root/f'state/data/nginx/ddns/{a["id"]}.conf').read_text()
start=time.monotonic();b=create('Slow DNS batch',[{'hostname':n,'auto_refresh':False}for n in slow]);save_seconds=time.monotonic()-start
assert save_seconds<6,save_seconds
print('Saving 3 timeout domains returns without synchronous DNS batch: PASS',round(save_seconds,2),'seconds',flush=True)
deadline=time.monotonic()+20
while time.monotonic()<deadline:
 if 'allow 'not in(root/f'state/data/nginx/ddns/{a["id"]}.conf').read_text():break
 time.sleep(.2)
else:raise AssertionError('Slow batch blocked TTL watchdog')
deadline=time.monotonic()+20
while time.monotonic()<deadline:
 r=api('GET',f'/nginx/access-lists/{a["id"]}/ddns')[0]
 if r['status']=='Error' and r['error']=='STALE_IP_EXPIRED':break
 time.sleep(.2)
else:raise AssertionError(f'Expected stale TTL error, got {r["status"]}/{r["error"]}')
print('Other Access List stale grants expire while slow DNS jobs run: PASS',flush=True)
(root/'batch-results.json').write_text(json.dumps({'result':'PASS','batch_save_seconds':round(save_seconds,2),'ttl_watchdog_with_slow_batch':'PASS','scope':'staging only; DNS timeout fixture'},indent=2))
