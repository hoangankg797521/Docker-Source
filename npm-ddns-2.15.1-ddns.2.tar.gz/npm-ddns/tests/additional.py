"""Additional acceptance checks on the isolated Debian staging only."""
import json,sqlite3,time,urllib.request,urllib.error,secrets
from pathlib import Path
root=Path('/opt/npm-ddns-staging');token=None;results=[]
def api(method,p,data=None):
 headers={'Content-Type':'application/json'}
 if token:headers['Authorization']='Bearer '+token
 req=urllib.request.Request('http://127.0.0.1:18081/api'+p,method=method,headers=headers,data=json.dumps(data).encode()if data is not None else None)
 with urllib.request.urlopen(req,timeout=30)as r:return json.load(r)
def probe(name,ip,auth=None):
 headers={'Host':name,'X-Real-IP':ip}
 if auth:headers['Authorization']=auth
 try:
  with urllib.request.urlopen(urllib.request.Request('http://127.0.0.1:18080/',headers=headers),timeout=10)as r:return r.status
 except urllib.error.HTTPError as e:return e.code

def wait(name,ip,status,auth=None):
 for _ in range(30):
  if probe(name,ip,auth)==status:return
  time.sleep(.2)
 raise AssertionError('Unexpected HTTP status')
def record(name):results.append(name);print(name+': PASS',flush=True)
for i in range(150):
 try:token=api('POST','/tokens',{'identity':'staging@example.test','secret':(root/'secrets/admin-password').read_text().strip()})['token'];break
 except Exception:
  if i==149:raise
  time.sleep(1)
run=str(int(time.time()));config_path=root/'fixtures/dns.json';config=json.loads(config_path.read_text());config['ipv6.example.test']={'a':['8.8.8.8'],'aaaa':['2606:4700:4700::1111']};config['noauto.example.test']={'a':['1.1.1.1']};config_path.write_text(json.dumps(config))
def acl(name,clients=None,ddns=None,items=None,satisfy=False):
 result=api('POST','/nginx/access-lists',{'name':name+' '+run,'satisfy_any':satisfy,'pass_auth':False,'items':items or [],'clients':clients or [],**({'ddns_rules':ddns}if ddns is not None else{})})
 if ddns:
  for _ in range(120):
   if all(r['status']!='Updating' or not r['enabled'] for r in api('GET',f'/nginx/access-lists/{result["id"]}/ddns')):break
   time.sleep(.25)
  else:raise AssertionError('Initial DNS job did not finish')
 return result

def host(name,lid):return api('POST','/nginx/proxy-hosts',{'domain_names':[name],'forward_scheme':'http','forward_host':'127.0.0.1','forward_port':81,'access_list_id':lid,'certificate_id':0,'ssl_forced':False,'locations':[]})
# Replay every production manual rule, using a read-only backup, without changing production.
db=sqlite3.connect('file:/var/backups/npm-ddns/20261016T074227Z/database.sqlite?mode=ro',uri=True);manual=[{'directive':d,'address':a}for d,a in db.execute('select directive,address from access_list_client order by id')];db.close()
a=acl('All production manual clients',manual);name='all-manual-'+run+'.example.test';h=host(name,a['id'])
import ipaddress
for r in manual:
 ip=str(ipaddress.ip_network(r['address']).network_address+5)if '/'in r['address']else r['address'];wait(name,ip,200)
wait(name,'9.9.9.9',403)
text=(root/f'state/data/nginx/proxy_host/{h["id"]}.conf').read_text();positions=[text.index(r['directive']+' '+r['address']+';')for r in manual];assert positions==sorted(positions);assert '/ddns/'not in text
record('All 9 production manual IP/CIDR rules and original ordering replayed through HTTP')
a=acl('IPv6 opt-in',ddns=[{'hostname':'ipv6.example.test','ipv6':True}]);r=api('GET',f'/nginx/access-lists/{a["id"]}/ddns')[0];assert json.loads(r['addresses'])==['2606:4700:4700::1111','8.8.8.8'];name='ipv6-'+run+'.example.test';host(name,a['id']);wait(name,'2606:4700:4700::1111',200);wait(name,'2606:4700:4700::1001',403);record('IPv6 opt-in DNS AAAA, normalization, Nginx render and synthetic source ACL')
a=acl('IPv6 default disabled',ddns=[{'hostname':'ipv6.example.test'}]);r=api('GET',f'/nginx/access-lists/{a["id"]}/ddns')[0];assert not r['ipv6'];assert json.loads(r['addresses'])==['8.8.8.8'];record('IPv6 stays disabled by default')
a=acl('No auto refresh',ddns=[{'hostname':'noauto.example.test','auto_refresh':False,'stale_ttl':8}]);lid=a['id'];r=api('GET',f'/nginx/access-lists/{lid}/ddns')[0];time.sleep(10);r2=api('GET',f'/nginx/access-lists/{lid}/ddns')[0];assert r2['last_check']==r['last_check'];assert r2['status']=='Error' and r2['error']=='STALE_IP_EXPIRED';assert 'allow 'not in(root/f'state/data/nginx/ddns/{lid}.conf').read_text();record('Auto Refresh disabled stops DNS jobs, TTL still revokes and UI status becomes Error')
# Existing manual deny precedes dynamic grants.
a=acl('Manual deny order',[{'directive':'deny','address':'8.8.8.8'}],[{'hostname':'ipv6.example.test'}]);name='ordered-'+run+'.example.test';host(name,a['id']);wait(name,'8.8.8.8',403);record('Manual deny preserves first-match semantics ahead of DDNS allow')
# Empty DDNS payload must not change a legacy auth-only list into an IP deny policy.
a=acl('Legacy auth only',items=[{'username':'test','password':secrets.token_urlsafe(24)}]);api('PUT',f'/nginx/access-lists/{a["id"]}',{'name':a['name'],'satisfy_any':False,'pass_auth':False,'clients':[],'items':[{'username':'test','password':''}],'ddns_rules':[]});
db=sqlite3.connect('file:'+str(root/'state/data/database.sqlite')+'?mode=ro',uri=True);assert db.execute('select count(*)from access_list_ddns_policy where access_list_id=?',(a['id'],)).fetchone()[0]==0;db.close();record('Saving empty DDNS payload preserves legacy auth-only list')
(root/'additional-results.json').write_text(json.dumps({'result':'PASS','results':results},indent=2));print('ADDITIONAL_TESTS_PASSED',len(results))
