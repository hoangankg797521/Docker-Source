# Backup, phục hồi và rollback

## Phạm vi và điều kiện

Chưa được chạy cutover hoặc restore production nếu chưa có xác nhận riêng của quản trị viên. Không dùng `docker compose down -v`, không xóa volume, không ghi đè database đang chạy.

Backup chứa credential, JWT key và SSL private key: giữ trên server, thư mục `0700`, file `0600`; không đồng bộ Git. Backup đã kiểm tra lưu ở `/var/backups/npm-ddns/` và nằm ngoài thư mục Compose.

## Backup mới trước cutover

Chạy `python3 /opt/npm-ddns-staging/source/scripts/backup.py` trên server. Lấy đường dẫn từ `BACKUP_VERIFIED`, không dùng thư mục có marker `INCOMPLETE`. Backup dùng SQLite Backup API; so sánh `PRAGMA data_version` trên cùng connection và manifest file trước/sau khi archive. Nếu thay đổi, tạo timestamp khác; không xóa bộ trước.

Giữ bản Compose gốc, inspect container/image, image ID và digest gốc. Bản custom chỉ được tham chiếu bằng tag cố định/digest đã kiểm thử.

## Diễn tập phục hồi

Dùng `scripts/restore-test.py <backup-path>` trên Debian host. Script tạo checkout phục hồi riêng với timestamp, giải nén và kiểm tra SQLite, chạy `nginx -t` bằng image gốc trong container `--network none`, không công bố port. Log ghi tmpfs; database và SSL copy mount chỉ đọc. Không khởi động backend production trong môi trường này và không gọi Let's Encrypt.

Migration test `tests/migration.mjs` chạy trên bản sao database, nâng/hạ hai lần và đối chiếu toàn bộ row của bảng cũ. Không chạy file này trên database production.

## Khi cần rollback production

1. Ngừng các thao tác quản trị đang ghi và xác định khoảng thời gian từ snapshot đến hiện tại.
2. Tạo thêm backup trạng thái hiện tại trước rollback, kể cả nếu bản custom có lỗi.
3. Đối chiếu dữ liệu/config/certificate hiện tại với snapshot. Nếu có thay đổi hợp lệ sau snapshot, dừng restore tự động và lập phương án giữ/merge dữ liệu mới. Không ghi đè chỉ vì có backup cũ.
4. Sau xác nhận, dừng **riêng** container NPM; giữ các dịch vụ khác hoạt động. Di chuyển data hiện tại sang thư mục recovery có timestamp để bảo toàn, không xóa.
5. Phục hồi toàn bộ data từ archive và đặt file SQLite nhất quán `database.sqlite` vào đúng `/opt/npm/data/database.sqlite`; phục hồi Let's Encrypt chỉ khi cần, sau khi đã đối chiếu certificate mới.
6. Khôi phục Compose gốc và image gốc theo digest `jc21/nginx-proxy-manager@sha256:52b2c59994f3d36acfcf70a1626f29734df0ed8c71bacc0269f78b6f939858bb`; không pull `latest`.
7. Chạy `nginx -t` trên bộ phục hồi trước khi mở dịch vụ. Khởi động lại riêng service NPM với volumes/network/ports gốc.
8. Kiểm tra migration list tương thích image gốc, API, Proxy Host, Access List, SSL và routing. Giữ nguyên cả backup trước cutover lẫn bản recovery mới.

Không chỉ đổi image về bản cũ trong khi giữ database có migration custom: Knex kiểm tra danh sách migration, image cũ không có file custom. Khôi phục snapshot database trước migration là đường rollback ưu tiên. Một phương án down-migration giữ dữ liệu mới chỉ được thực hiện sau khi đánh giá ảnh hưởng và diễn tập riêng; DDNS-only list sẽ không có ngữ nghĩa tương đương trên bản NPM gốc.

## Thời gian gián đoạn

Cutover thay một container nên có gián đoạn ngắn trong lúc stop/start và backend khởi động. Không bảo đảm giữ toàn bộ TCP/WebSocket đang mở. Ước tính phải dựa trên lần diễn tập staging cuối cùng, cộng thời gian backup/kiểm tra; không hứa zero downtime.
