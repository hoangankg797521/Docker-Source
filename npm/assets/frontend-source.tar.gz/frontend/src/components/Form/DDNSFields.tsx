import { useCallback, useEffect, useState } from "react";
import { useFormikContext } from "formik";
import * as api from "src/api/backend/base";

type Rule = {
	id?: number;
	hostname: string;
	enabled: boolean;
	ipv6: boolean;
	autoRefresh: boolean;
	refreshInterval: number;
	staleTtl: number;
	addresses?: string;
	status?: string;
	lastCheck?: number;
	lastChange?: number;
	error?: string;
};
const blank = (): Rule => ({
	hostname: "",
	enabled: true,
	ipv6: false,
	autoRefresh: true,
	refreshInterval: 60,
	staleTtl: 300,
});
const payload = (r: Rule) => ({
	...(r.id ? { id: r.id } : {}),
	hostname: r.hostname,
	enabled: !!r.enabled,
	ipv6: !!r.ipv6,
	autoRefresh: !!r.autoRefresh,
	refreshInterval: r.refreshInterval,
	staleTtl: r.staleTtl,
});
export function DDNSFields({ listId }: { listId: number | "new" }) {
	const { setFieldValue } = useFormikContext();
	const [rules, setRules] = useState<Rule[]>([]);
	const [error, setError] = useState("");
	const [busy, setBusy] = useState(false);
	const [history, setHistory] = useState<any[] | null>(null);
	const publish = useCallback(
		(next: Rule[]) => {
			setRules(next);
			setFieldValue("ddnsRules", next.map(payload));
		},
		[setFieldValue],
	);
	useEffect(() => {
		let active = true;
		let initial = true;
		const fetchStatus = () => {
			if (listId === "new") return;
			api.get({ url: `/nginx/access-lists/${listId}/ddns` })
				.then((fresh: Rule[]) => {
					if (!active) return;
					if (initial) {
						initial = false;
						if (fresh.length) setFieldValue("ddnsConfigured", true);
						publish(fresh);
					} else
						setRules((old) =>
							old.map((r) => {
								const f = fresh.find((x) => x.id === r.id);
								return f
									? {
											...r,
											addresses: f.addresses,
											status: f.status,
											lastCheck: f.lastCheck,
											lastChange: f.lastChange,
											error: f.error,
										}
									: r;
							}),
						);
				})
				.catch((e: Error) => {
					if (active) setError(e.message);
				});
		};
		fetchStatus();
		const timer = setInterval(fetchStatus, 10000);
		return () => {
			active = false;
			clearInterval(timer);
		};
	}, [listId, publish, setFieldValue]);
	const update = (i: number, key: keyof Rule, value: any) =>
		publish(rules.map((r, j) => (i === j ? { ...r, [key]: value } : r)));
	const act = async (r: Rule, kind: "refresh" | "history") => {
		if (!r.id) return;
		setBusy(true);
		setError("");
		try {
			const url = `/nginx/access-lists/${listId}/ddns/${r.id}/${kind}`;
			if (kind === "history") setHistory(await api.get({ url }));
			else {
				const fresh = await api.post({ url });
				setRules((old) =>
					old.map((x) =>
						x.id === r.id
							? {
									...x,
									addresses: fresh.addresses,
									status: fresh.status,
									lastCheck: fresh.lastCheck,
									lastChange: fresh.lastChange,
									error: fresh.error,
								}
							: x,
					),
				);
			}
		} catch (e: any) {
			setError(e.message);
		} finally {
			setBusy(false);
		}
	};
	return (
		<section aria-label="DDNS / Domain rules" className="mt-3">
			<h3>DDNS / Domain</h3>
			<p className="text-muted">
				Enter a hostname directly. DDNS grants follow manual IP/CIDR rules. DNS errors retain the last good IP
				only until Stale IP TTL; then dynamic grants are revoked. Private and reserved DNS answers are rejected.
			</p>
			{error && (
				<div role="alert" className="alert alert-danger">
					{error}
				</div>
			)}
			{rules.map((r, i) => {
				let ips: string[] = [];
				try {
					ips = JSON.parse(r.addresses || "[]");
				} catch {}
				return (
					<div className="card mb-3" key={r.id || `new-${i}`}>
						<div className="card-body p-3">
							<label className="form-label" htmlFor={`ddns-host-${i}`}>
								Hostname
							</label>
							<input
								id={`ddns-host-${i}`}
								className="form-control mb-2"
								required
								maxLength={253}
								placeholder="home.example.com"
								value={r.hostname}
								onChange={(e) => update(i, "hostname", e.target.value)}
							/>
							<div className="row g-2 mb-2">
								<div className="col-6">
									<label className="form-label" htmlFor={`ddns-interval-${i}`}>
										Refresh interval (seconds)
									</label>
									<input
										id={`ddns-interval-${i}`}
										type="number"
										min={60}
										max={86400}
										required
										className="form-control"
										value={r.refreshInterval}
										onChange={(e) => update(i, "refreshInterval", Number(e.target.value))}
									/>
								</div>
								<div className="col-6">
									<label className="form-label" htmlFor={`ddns-ttl-${i}`}>
										Stale IP TTL (seconds)
									</label>
									<input
										id={`ddns-ttl-${i}`}
										type="number"
										min={0}
										max={604800}
										required
										className="form-control"
										value={r.staleTtl}
										onChange={(e) => update(i, "staleTtl", Number(e.target.value))}
									/>
								</div>
							</div>
							<div className="d-flex flex-wrap gap-3 mb-3">
								{(["enabled", "autoRefresh", "ipv6"] as const).map((k) => (
									<label key={k} className="form-check">
										<input
											className="form-check-input"
											type="checkbox"
											checked={r[k]}
											onChange={(e) => update(i, k, e.target.checked)}
										/>
										<span className="form-check-label">
											{k === "autoRefresh" ? "Auto Refresh" : k === "ipv6" ? "IPv6" : "Enabled"}
										</span>
									</label>
								))}
							</div>
							<dl className="row mb-2 small">
								<dt className="col-5">Type / DNS Status</dt>
								<dd className="col-7">
									DDNS / {r.enabled ? r.status || "Updating" : "Disabled"} {r.error && `(${r.error})`}
								</dd>
								<dt className="col-5">Resolved IPv4</dt>
								<dd className="col-7 text-break">
									{ips.filter((ip) => !ip.includes(":")).join(", ") || "—"}
								</dd>
								<dt className="col-5">Resolved IPv6</dt>
								<dd className="col-7 text-break">
									{ips.filter((ip) => ip.includes(":")).join(", ") || (r.ipv6 ? "—" : "Disabled")}
								</dd>
								<dt className="col-5">Last Checked</dt>
								<dd className="col-7">
									{r.lastCheck ? new Date(Number(r.lastCheck)).toLocaleString() : "—"}
								</dd>
								<dt className="col-5">Last Changed</dt>
								<dd className="col-7">
									{r.lastChange ? new Date(Number(r.lastChange)).toLocaleString() : "—"}
								</dd>
							</dl>
							<div className="d-flex flex-wrap gap-2">
								<button
									type="button"
									className="btn btn-sm"
									disabled={!r.id || busy}
									onClick={() => act(r, "refresh")}
								>
									Refresh DNS Now
								</button>
								<button
									type="button"
									className="btn btn-sm"
									disabled={!r.id || busy}
									onClick={() => act(r, "history")}
								>
									View History
								</button>
								<button
									type="button"
									className="btn btn-sm btn-outline-danger"
									onClick={() => publish(rules.filter((_, j) => j !== i))}
								>
									Delete DDNS Rule
								</button>
							</div>
						</div>
					</div>
				);
			})}
			<button type="button" className="btn btn-sm mb-3" onClick={() => publish([...rules, blank()])}>
				Add DDNS Rule
			</button>
			<p className="small text-muted">
				Save the Access List to apply edits. After DDNS is used, an empty DDNS-only list stays closed. Existing
				authentication and Satisfy Any settings still apply.
			</p>
			{history && (
				<div className="table-responsive">
					<button type="button" className="btn btn-sm mb-2" onClick={() => setHistory(null)}>
						Close History
					</button>
					<table className="table table-sm">
						<thead>
							<tr>
								<th>Checked</th>
								<th>Event</th>
								<th>Addresses / Error</th>
							</tr>
						</thead>
						<tbody>
							{history.map((h) => (
								<tr key={h.id}>
									<td>{new Date(Number(h.checkedAt)).toLocaleString()}</td>
									<td>{h.event}</td>
									<td className="text-break">{h.error || h.addresses}</td>
								</tr>
							))}
						</tbody>
					</table>
				</div>
			)}
		</section>
	);
}
