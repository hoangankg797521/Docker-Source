#!/command/with-contenv bash
# Sourced by NPM prepare, before both Nginx and backend services start.
# Empty managed includes remain under the existing ACL's final `deny all`.
# The backend watchdog restores only currently valid grants after startup.
if [ -L /data/nginx/ddns ]; then
 log_fatal 'Managed DDNS directory must not be a symlink.'
 exit 1
fi
mkdir -p /data/nginx/ddns
chown "$PUID:$PGID" /data/nginx/ddns
ddns_startup_count=0
for ddns_startup_file in /data/nginx/ddns/*.conf; do
 if [ -L "$ddns_startup_file" ]; then
  log_fatal 'Managed DDNS include must not be a symlink.'
  exit 1
 fi
 [ -f "$ddns_startup_file" ] || continue
 printf '# Managed DDNS grants; manual rules precede this include.\n' > "$ddns_startup_file"
 ddns_startup_count=$((ddns_startup_count + 1))
done
printf '{"scope":"ddns","event":"startup_fail_closed","includes":%s}\n' "$ddns_startup_count"
