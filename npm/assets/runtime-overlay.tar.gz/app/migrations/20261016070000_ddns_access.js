export async function up(knex) {
	await knex.schema.createTable("access_list_ddns_policy", (t) => {
		t.integer("access_list_id").primary();
	});
	await knex.schema.createTable("access_list_ddns", (t) => {
		t.increments("id");
		t.integer("access_list_id").notNullable().index();
		t.string("hostname", 253).notNullable();
		for (const [key, def] of [
			["enabled", true],
			["ipv6", false],
			["auto_refresh", true],
		])
			t.boolean(key).notNullable().defaultTo(def);
		t.integer("refresh_interval").notNullable().defaultTo(60);
		t.integer("stale_ttl").notNullable().defaultTo(300);
		t.text("addresses").notNullable().defaultTo("[]");
		t.string("status", 32).notNullable().defaultTo("Updating");
		for (const key of ["last_success", "last_check", "last_change", "next_check"]) t.bigInteger(key).nullable();
		t.integer("failures").notNullable().defaultTo(0);
		t.string("error", 128).nullable();
		t.unique(["access_list_id", "hostname"]);
	});
	await knex.schema.createTable("access_list_ddns_history", (t) => {
		t.increments("id");
		t.integer("rule_id").notNullable().index();
		t.bigInteger("checked_at").notNullable();
		t.string("event", 32).notNullable();
		t.text("addresses").notNullable();
		t.string("error", 128).nullable();
	});
}
export async function down(knex) {
	await knex.schema.dropTable("access_list_ddns_history");
	await knex.schema.dropTable("access_list_ddns");
	await knex.schema.dropTable("access_list_ddns_policy");
}
